//
//  UserModel.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 19/04/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit

class UserModel: NSObject {
    
    var id : String = ""
    var image : String = ""
    var name: String = ""
    var email : String = ""
    var artistType: String = ""
    var phoneNumber: String = ""
    var portfolioImages : String = ""
    var ArtistCategoryid: String = ""

    struct KeyPlacesData  {
        static let id = "userid"
        static let image = "image"
        static let name = "name"
        static let email = "email"
        static let artistType = "artistType"
        static let phoneNumber = "phoneNumber"
        static let portfolioImages = "portfolioImages"
        static let ArtistCategoryid = "ArtistCategoryid"
    }
    
    override init(){
    }
    
    init(dict : NSDictionary){
        self.id = dict.getString(key: KeyPlacesData.id)
        self.image = dict.getString(key: KeyPlacesData.image)
        self.name = dict.getString(key: KeyPlacesData.name)
        self.email = dict.getString(key: KeyPlacesData.email)
        self.artistType = dict.getString(key: KeyPlacesData.artistType)
        self.phoneNumber = dict.getString(key: KeyPlacesData.phoneNumber)
        self.portfolioImages = dict.getString(key: KeyPlacesData.portfolioImages)
        self.ArtistCategoryid = dict.getString(key: KeyPlacesData.ArtistCategoryid)
    }
}
