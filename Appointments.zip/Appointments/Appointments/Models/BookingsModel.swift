//
//  BookingsModel.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 19/04/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit

class BookingsModel: NSObject {
    
    var id : String = ""
    var bookTime : String = ""
    var bookMessage: String = ""
    var bookingDate: String = ""
    var userId: String = ""
    var userName: String = ""
    var userImage: String = ""
    var userCategoryType: String = ""

    struct KeyPlacesData  {
        
        static let id = "Bookingsid"
        static let bookTime = "bookTime"
        static let bookMessage = "bookMessage"
        static let bookingDate = "bookingDate"
        static let userId = "userId"
        static let userName = "userName"
        static let userImage = "userImage"
        static let userCategoryType = "userCategoryType"

    }
    
    override init(){
    }
    
    init(dict : NSDictionary){
        self.id = dict.getString(key: KeyPlacesData.id)
        self.bookTime = dict.getString(key: KeyPlacesData.bookTime)
        self.bookMessage = dict.getString(key: KeyPlacesData.bookMessage)
        self.bookingDate = dict.getString(key: KeyPlacesData.bookingDate)
        self.userId = dict.getString(key: KeyPlacesData.userId)
        self.userName = dict.getString(key: KeyPlacesData.userName)
        self.userImage = dict.getString(key: KeyPlacesData.userImage)
        self.userCategoryType = dict.getString(key: KeyPlacesData.userCategoryType)

    }
}
