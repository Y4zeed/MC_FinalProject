//
//  CategoriesModel.swift
//  Appointments
//
//  Created by A Yazeed Alshunify on 12/04/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit

class CategoriesModel: NSObject {
    
    var id : String = ""
    var artistType : String = ""
    var artistImage: String = ""
    
    struct KeyPlacesData  {
        static let id = "ArtistCategoryid"
        static let artistType = "ArtistType"
        static let artistImage = "ArtistImage"
    }
    
    override init(){
    }
    
    init(dict : NSDictionary){
        self.id = dict.getString(key: KeyPlacesData.id)
        self.artistType = dict.getString(key: KeyPlacesData.artistType)
        self.artistImage = dict.getString(key: KeyPlacesData.artistImage)
    }
}
