//
//  AppointmentsRequestsVC.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 29/03/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit
import FSCalendar

class cellAppoitmentReq: UITableViewCell {
    
    @IBOutlet weak var contrlImg: UIControl!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblDateTitle: UILabel!
    @IBOutlet weak var lblTimeTitle: UILabel!
    @IBOutlet weak var lblNoteTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblNote: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var imgProfile: UIImageView!
}
class AppointmentsRequestsVC: UIViewController {
    
    //Reference Outlest...
    @IBOutlet weak var tblAppointmentReq: UITableView!
    @IBOutlet weak var controlBack: UIControl!
    @IBOutlet weak var calander: FSCalendar?
    @IBOutlet weak var lblNoDataAvailable: UILabel!
    
    //Variables.
    var strSelectedDate = ""
    var arrBookingsData = [BookingsModel]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setUIAndTheme()
    }
    
    //MARK: - UI initializations....
    func setUIAndTheme(){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.strSelectedDate = formatter.string(from: Date())
        
        self.lblNoDataAvailable.isHidden = true
        self.calander?.appearance.titleFont = calnderFont
        self.calander?.appearance.weekdayFont = calnderFont
        self.calander?.appearance.subtitleFont = calnderFont
        self.calander?.appearance.headerTitleFont = calnderFont
        self.calander?.appearance.todaySelectionColor = UIColor.lightGray
        self.calander?.appearance.todayColor = UIColor.lightGray
        self.calander?.appearance.selectionColor = goldThemeColor
        self.getAllBookingsData(aSelectedDate: self.strSelectedDate)
    }
    
    //MARK: - Get date wise bookings data from Local Database....
    func getAllBookingsData(aSelectedDate : String)
    {
        self.arrBookingsData = appDelegate.databaseModel.getBookingDataAsPerDate(aDate: aSelectedDate)
        if self.arrBookingsData .count > 0
        {
            self.lblNoDataAvailable.isHidden = true
        }else{
            self.lblNoDataAvailable.isHidden = false
        }
        self.tblAppointmentReq.reloadData()
    }
}

//Click Events..
extension AppointmentsRequestsVC {
    @IBAction func clickOnBack(_ sender: UIControl) {
            self.navigationController?.popViewController(animated: true)
    }
}
extension AppointmentsRequestsVC :UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  self.arrBookingsData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellAppoitmentReq", for: indexPath) as? cellAppoitmentReq
        cell?.selectionStyle = .none
        cell?.lblUserName.text = self.arrBookingsData[indexPath.row].userName
        cell?.lblTime.text = self.arrBookingsData[indexPath.row].bookTime
        cell?.lblDate.text = self.arrBookingsData[indexPath.row].bookingDate
        cell?.lblNote.text = self.arrBookingsData[indexPath.row].bookMessage
        return cell!
    }
}
extension AppointmentsRequestsVC : FSCalendarDataSource{
    
}

extension AppointmentsRequestsVC : FSCalendarDelegate{
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        if !date.isWeekend
        {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd" //2019-09-22
            self.strSelectedDate = formatter.string(from: date)
            self.lblNoDataAvailable.isHidden = true
            self.getAllBookingsData(aSelectedDate: self.strSelectedDate)
//            self.tblAppointmentReq.isHidden = false
//            self.tblAppointmentReq.reloadData()
        }else{
            self.popupAlert(title: "Alert", message: "You haven't any appointment on weekends", actionTitles: ["OK"], actions:[nil])
//             self.tblAppointmentReq.reloadData()
//             self.lblNoDataAvailable.isHidden = false
//             self.tblAppointmentReq.isHidden = true
        }
    }
}
