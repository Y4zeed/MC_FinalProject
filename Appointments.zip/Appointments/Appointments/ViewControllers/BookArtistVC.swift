//
//  BookArtistVC.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 29/03/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit
import FSCalendar

class cellBookingTime:UICollectionViewCell{
    @IBOutlet weak var viewConteiner: UIView!
    @IBOutlet weak var lblBookingTime: UILabel!
}

class BookArtistVC: UIViewController {
    
    //Reference Outlets..
    @IBOutlet weak var imguser: UIImageView!
    @IBOutlet weak var lbluserDescription: UILabel!
    @IBOutlet weak var lbluserName: UILabel!
    @IBOutlet weak var lblSelectTimeTitle: UILabel!
    @IBOutlet weak var collBookingTime: UICollectionView!
    @IBOutlet weak var txtMsgBooking: UITextField!
    @IBOutlet weak var consHeightCollBookingTime: NSLayoutConstraint!
    @IBOutlet weak var calander: FSCalendar?
    @IBOutlet weak var lblNoDataAvailable: UILabel!
    
    //var
    var arrBookingSlot = ["09 am - 10 am","10 am - 11 am","12 am - 01 pm","01 pm - 02 pm","02 pm - 03 pm","03 pm - 04 pm","04 pm - 05 pm","06 pm - 07 pm","07 pm - 08 pm"]
    var strSelectedTime = ""
    var strSelectedDate = ""
    var dictUserData = UserModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.async {
            self.view.layoutIfNeeded()
            self.setUIAndTheme()
            self.setData()
        }
    }
    //MARK: - UI initializations....
    func setUIAndTheme(){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.strSelectedDate = formatter.string(from: Date())
        self.lblNoDataAvailable.isHidden = true
        self.txtMsgBooking.setLeftPaddingPoints(15)
        
        //Calender view setup with colors...
        self.calander?.appearance.titleFont = calnderFont
        self.calander?.appearance.weekdayFont = calnderFont
        self.calander?.appearance.subtitleFont = calnderFont
        self.calander?.appearance.headerTitleFont = calnderFont
        self.calander?.appearance.todaySelectionColor = UIColor.lightGray
        self.calander?.appearance.todayColor = UIColor.lightGray
        self.calander?.appearance.selectionColor = goldThemeColor
        self.reloadCell()
    }
    
    //MARK: - Set user data...
    func setData()  {
        self.lbluserDescription.text = self.dictUserData.email
        self.lbluserName.text = self.dictUserData.name
        self.imguser.image = UIImage.init(named:self.dictUserData.image)
    }
    
    func reloadCell(){
        DispatchQueue.main.async {
            self.collBookingTime.reloadData()
            DispatchQueue.main.async {
                self.consHeightCollBookingTime.constant = self.collBookingTime.contentSize.height
            }
        }
    }
    
    //MARK: - Book time and date from calender..
    func bookUserAppointment()
    {
        let isSuccess = appDelegate.databaseModel.insertBookingData(bookTime: self.strSelectedTime, bookMessage: self.txtMsgBooking.text!, bookingDate: self.strSelectedDate, userId: self.dictUserData.id, userName: self.dictUserData.name, userImage: self.dictUserData.image, userCategoryType: self.dictUserData.artistType)
        
        if isSuccess
        {
            self.popupAlert(title: "Booked Successfully", message: "Booking request has been sent!", actionTitles: ["OK"], actions:[{action1 in
                for VC in (self.navigationController?.viewControllers)! {
                    if VC is ArtistsListVC {
                        let vcontroll  : ArtistsListVC = VC as! ArtistsListVC
                        self.navigationController?.popToViewController(vcontroll, animated: true)
                    }
                }}, nil])
        }else{
            self.popupAlert(title: "Error", message: "Booking request has been not sent. Please try again later!", actionTitles: ["OK"], actions:[nil])
        }
    }
}

//MARK: - click events
extension BookArtistVC{
    @IBAction func clickOnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func clickOnDone(_ sender: UIButton) {
        
        if self.txtMsgBooking.text! != ""
        {
            self.bookUserAppointment()
        }else{
            self.popupAlert(title: "Alert", message: "Please add note for artist reference!", actionTitles: ["OK"], actions:[nil])
        }
    }
}

extension BookArtistVC:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let flowayout = collectionViewLayout as? UICollectionViewFlowLayout
        let space: CGFloat = (flowayout?.minimumInteritemSpacing ?? 0.0) + (flowayout?.sectionInset.left ?? 0.0) + (flowayout?.sectionInset.right ?? 0.0)
        let size:CGFloat = (self.collBookingTime.frame.size.width - (space*3)) / 3
        return CGSize(width: size, height: 45)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrBookingSlot.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellBookingTime", for: indexPath) as? cellBookingTime
        cell?.viewConteiner.backgroundColor = UIColor.clear
        if indexPath.row == self.collBookingTime.tag{
            cell?.viewConteiner.backgroundColor = goldThemeColor
        }else{
            cell?.viewConteiner.backgroundColor =  UIColor.clear
        }
        //        cell?.lblBookingTime.textColor = UIColor.black
        cell?.lblBookingTime.text = self.arrBookingSlot[indexPath.row]
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.strSelectedTime = self.arrBookingSlot[indexPath.row]
        self.collBookingTime.tag = indexPath.row
        self.reloadCell()
    }
}
extension BookArtistVC : FSCalendarDelegate{
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        if !date.isWeekend
        {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd" //2019-09-22
            self.strSelectedDate = formatter.string(from: date)
            self.collBookingTime.isHidden = false
            self.lblNoDataAvailable.isHidden = true
            self.collBookingTime.reloadData()
            
        }else{
            self.popupAlert(title: "Alert", message: "Artist would not be available on weekends", actionTitles: ["OK"], actions:[nil])
            self.collBookingTime.isHidden = true
            self.lblNoDataAvailable.isHidden = false
        }
    }
}

extension Date {
    var isWeekend: Bool {
        return NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!.isDateInWeekend(self)
    }
}
