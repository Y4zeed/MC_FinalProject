//
//  BookedappointmentsVC.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 29/03/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit

class CellAppotmentBooked: UITableViewCell {
    @IBOutlet weak var contrlImg: UIControl!
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblNote: UILabel!
    @IBOutlet weak var lblTime: UILabel!
}

class BookedAppointmentsVC: UIViewController {
    
    //Reference Outlets..
    @IBOutlet weak var tblAppointment: UITableView!
    @IBOutlet weak var lblNoDataAvailable: UILabel!
    
    //Variables...
    var arrBookingsData = [BookingsModel]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblAppointment.tableFooterView = UIView()
        self.lblNoDataAvailable.isHidden = true
        self.getAllBookingsData()
    }
    
    //MARK: - Get all bookings from Local Database....
    func getAllBookingsData()
    {
        self.arrBookingsData = appDelegate.databaseModel.getAllBookingsData()
        if self.arrBookingsData .count > 0
        {
            self.lblNoDataAvailable.isHidden = true
            self.tblAppointment.isHidden = false
            
        }else{
            self.lblNoDataAvailable.isHidden = false
            self.tblAppointment.isHidden = true
        }
        self.tblAppointment.reloadData()
    }
}

//MARK: - Click Events..
extension BookedAppointmentsVC {
    @IBAction func clickOnBack(_ sender: UIControl) {
        self.navigationController?.popViewController(animated: true)
    }
}

//MARK: - Tableview Delegates and DataSource methods...
extension BookedAppointmentsVC :UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrBookingsData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellAppotmentBooked", for: indexPath) as? CellAppotmentBooked
        cell?.imgProfile.image = UIImage.init(named:self.arrBookingsData[indexPath.row].userImage)
        cell?.lblUserName.text = "\(self.arrBookingsData[indexPath.row].userName) - \(self.arrBookingsData[indexPath.row].userCategoryType)"
        cell?.lblDate.text = self.arrBookingsData[indexPath.row].bookingDate
        cell?.lblTime.text = self.arrBookingsData[indexPath.row].bookTime
        cell?.lblNote.text = self.arrBookingsData[indexPath.row].bookMessage
        return cell!
    }
}
