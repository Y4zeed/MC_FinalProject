//
//  ArtistDetailsVC.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 29/03/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit

class ArtistDetailsVC: UIViewController {
    
    //Refrence Outlets..
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtArtistType: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPhoneNumber: UITextField!
    @IBOutlet weak var controlEditProfile: UIControl!
    @IBOutlet weak var btnEditProfile: UIButton!
    @IBOutlet weak var imgPorfolio: UIImageView!

    //Variables...
    var isFromArtist = true
    var dictUserData = UserModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initialisation()
    }
    
    //MARK: - Initialise data..
    func initialisation()
    {
        if isFromArtist
        {
            self.controlEditProfile.isHidden = true
            self.textfieldEditable(isEditable: false)
        }else{
            btnEditProfile.setTitle("Update Profile", for: .normal)
            self.textfieldEditable(isEditable: true)
        }
        self.setupaArtistProfileData()
        self.txtName.setLeftPaddingPoints(10)
        self.txtEmail.setLeftPaddingPoints(10)
        self.txtArtistType.setLeftPaddingPoints(10)
        self.txtPhoneNumber.setLeftPaddingPoints(10)
    }
    
    //MARK: - Setup Textfield Editable or not.
    func textfieldEditable(isEditable:Bool)
    {
        self.txtName.isUserInteractionEnabled = isEditable
        self.txtEmail.isUserInteractionEnabled = isEditable
        self.txtArtistType.isUserInteractionEnabled = isEditable
        self.txtPhoneNumber.isUserInteractionEnabled = isEditable
    }
    
    //MARK: - Setup Artist Profile Data..
    func setupaArtistProfileData()
    {
        self.txtName.text = self.dictUserData.name
        self.txtEmail.text = self.dictUserData.email
        self.txtArtistType.text = self.dictUserData.artistType
        self.txtPhoneNumber.text = self.dictUserData.phoneNumber
        self.imgProfile.image = UIImage.init(named:self.dictUserData.image)
        self.imgPorfolio.image = UIImage.init(named:self.dictUserData.portfolioImages)
    }
}

//MARK: - Click Events..
extension ArtistDetailsVC
{
    @IBAction func tapToBack(_ sender: UIControl) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func tapToEditImage(_ sender: UIControl) {
    }
    @IBAction func tapToEditProfile(_ sender: UIButton) {
        if isFromArtist
        {
            let objBookArtist = self.storyboard?.instantiateViewController(withIdentifier: "BookArtistVC") as! BookArtistVC
            objBookArtist.dictUserData = self.dictUserData
            self.navigationController?.pushViewController(objBookArtist, animated: true)
        }else{
            
        }
    }
}

//MARK: - Textfield delegates...
extension ArtistDetailsVC : UITextFieldDelegate
{
    //MARK: - UITextField Delegates...
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        textField.autocorrectionType = .no
        
        UIView.animate(withDuration: 0.2) {
            self.view.layoutIfNeeded()
        }
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtPhoneNumber
        {
            let maxLength = 11
            let currentString: NSString = textField.text! as NSString
            let newString: NSString =
                currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
        }
        return true
    }
}
