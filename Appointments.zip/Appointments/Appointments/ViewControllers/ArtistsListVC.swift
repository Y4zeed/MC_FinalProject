//
//  ArtistsListVC.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 29/03/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit

class ArtistsListVC: UIViewController {
    
    //Reference Outlest..
    @IBOutlet var collArtistType: UICollectionView!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var txtSearch: UITextField!
    
    //Variables..
    var isSearchOpen = false
    var arrUserData = [UserModel]()
    var arrUserDataCopy = [UserModel]()
    var strSearchText : String = ""
    var strSelectedCategory : String = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        self.searchView.isHidden = true
        self.getAllInsertedData()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    //MARK: - Get all Users as per selected category from User table....
    func getAllInsertedData()
    {
        self.arrUserData = appDelegate.databaseModel.getUserDataAsPerCategories(aCatId:strSelectedCategory)
        self.arrUserDataCopy = appDelegate.databaseModel.getUserDataAsPerCategories(aCatId:strSelectedCategory)
        self.collArtistType.reloadData()
    }
}

//MARK: - click events...
extension ArtistsListVC{
    @IBAction func clickOnSearch(_ sender: UIButton) {
        if !isSearchOpen
        {
            isSearchOpen = true
            setView(view: searchView, hidden: false)
            self.txtSearch.becomeFirstResponder()
        }else{
            isSearchOpen = false
            setView(view: searchView, hidden: true)
            self.txtSearch.resignFirstResponder()
            self.searchDataClose()
        }
    }
     @IBAction func tapToBack(_ sender: UIControl) {
        self.navigationController?.popViewController(animated: true)
    }
}
//MARK: - Textfield delegates...
extension ArtistsListVC : UITextFieldDelegate
{
    //MARK: - UITextField Delegates...
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        textField.autocorrectionType = .no
        
        UIView.animate(withDuration: 0.2) {
            self.view.layoutIfNeeded()
        }
        
        return true
    }
    @IBAction func searchingWord(_ sender: UITextField) {
        
        let strText = txtSearch.text?.trimmingCharacters(in: .whitespaces)
        
        if strText!.count >= 3
        {
            self.arrUserData.removeAll()
            self.strSearchText = strText!.lowercased()
            self.arrUserData = self.arrUserDataCopy.filter ({$0.name.lowercased().contains(self.strSearchText)})
            self.collArtistType.reloadData()
        }
        else if strText!.count == 0 || strText! == ""
        {
            self.searchDataClose()
        }
    }
    
    func searchDataClose()
    {
        self.arrUserData.removeAll()
        self.arrUserData.append(contentsOf: self.arrUserDataCopy)
        self.collArtistType.reloadData()
        self.txtSearch.text = ""
        self.strSearchText = ""
    }
}
//MARK: - Extension for Collectionview delegates and datasources methods..
extension ArtistsListVC:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size:CGFloat = (self.collArtistType.frame.size.width - 20) / 3.0
        return CGSize(width: size, height: size + 50)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.arrUserData.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellArtistType", for: indexPath) as! CellArtistType
        cell.lblArtistType.text = self.arrUserData[indexPath.row].name
        cell.imgArtistType.image = UIImage.init(named:self.arrUserData[indexPath.row].image)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let objArtistDetailsVC = self.storyboard!.instantiateViewController(withIdentifier: "ArtistDetailsVC") as? ArtistDetailsVC
        objArtistDetailsVC!.isFromArtist = true
        objArtistDetailsVC?.dictUserData = self.arrUserData[indexPath.row]
        self.navigationController?.pushViewController(objArtistDetailsVC!, animated: true)
    }
}
