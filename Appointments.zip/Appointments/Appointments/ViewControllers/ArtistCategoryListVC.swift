//
//  ArtistCategoryListVC.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 29/03/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit

class CellArtistType: UICollectionViewCell {
    @IBOutlet weak var imgArtistType: UIImageView!
    @IBOutlet weak var lblArtistType: UILabel!
    @IBOutlet weak var mainView: UIView!
}

class ArtistCategoryListVC: UIViewController {
    
    //Reference Outlest..
    @IBOutlet var collArtistType: UICollectionView!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var txtSearch: UITextField!
    
    //Variables..
    //var allArtistTypes = [AllArtistType]()
    var isSearchOpen = false
    var arrCategoriesData = [CategoriesModel]()
    var arrCategoriesDataCopy = [CategoriesModel]()
    var strSearchText : String = ""

    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.searchView.isHidden = true
        self.getAllInsertedData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    //MARK: - Get all categories from Local Database....
    func getAllInsertedData()
    {
        self.arrCategoriesData = appDelegate.databaseModel.getCategoriesData()
        self.arrCategoriesDataCopy = appDelegate.databaseModel.getCategoriesData()
        self.collArtistType.reloadData()
    }
}

//MARK: - click events
extension ArtistCategoryListVC{
    @IBAction func clickOnSearch(_ sender: UIButton) {
        if !isSearchOpen
        {
            isSearchOpen = true
            setView(view: searchView, hidden: false)
            self.txtSearch.becomeFirstResponder()
        }else{
            isSearchOpen = false
            setView(view: searchView, hidden: true)
            self.txtSearch.resignFirstResponder()
            searchDataClose()
        }
    }
    @IBAction func tapToSettings(_ sender: UIButton) {
        let objBookingHistoryVC = self.storyboard!.instantiateViewController(withIdentifier: "BookingHistoryVC") as? BookingHistoryVC
        self.navigationController?.pushViewController(objBookingHistoryVC!, animated: true)
    }
}

//MARK: - Textfield delegates...
extension ArtistCategoryListVC : UITextFieldDelegate
{
    //MARK: - UITextField Delegates...
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        textField.autocorrectionType = .no
        
        UIView.animate(withDuration: 0.2) {
            self.view.layoutIfNeeded()
        }
        
        return true
    }
    @IBAction func searchingWord(_ sender: UITextField) {
        
        let strText = txtSearch.text?.trimmingCharacters(in: .whitespaces)
        
        if strText!.count >= 3
        {
            self.arrCategoriesData.removeAll()
            self.strSearchText = strText!.lowercased()
            self.arrCategoriesData = self.arrCategoriesDataCopy.filter ({$0.artistType.lowercased().contains(self.strSearchText)})
            self.collArtistType.reloadData()
        }
        else if strText!.count == 0 || strText! == ""
        {
            self.searchDataClose()
        }
    }
    
    func searchDataClose()
    {
        self.arrCategoriesData.removeAll()
        self.arrCategoriesData.append(contentsOf: self.arrCategoriesDataCopy)
        self.collArtistType.reloadData()
        self.txtSearch.text = ""
        self.strSearchText = ""
    }
}

//MARK: - Extension for Collectionview delegates and datasources methods..
extension ArtistCategoryListVC:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let flowayout = collectionViewLayout as? UICollectionViewFlowLayout
        let space: CGFloat = (flowayout?.minimumInteritemSpacing ?? 0.0) + (flowayout?.sectionInset.left ?? 0.0) + (flowayout?.sectionInset.right ?? 0.0)
        let size:CGFloat = (self.collArtistType.frame.size.width - space) / 2.0
        return CGSize(width: size, height: size + 50)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.arrCategoriesData.count
        //        if self.searchActive {
        //            return self.filtered.count
        //        }else{
        //            return self.allArtistTypes.count
        //        }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellArtistType", for: indexPath) as! CellArtistType
        cell.imgArtistType.image = UIImage.init(named:self.arrCategoriesData[indexPath.row].artistImage)
        cell.lblArtistType.text = self.arrCategoriesData[indexPath.row].artistType
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let objArtistsVC = self.storyboard!.instantiateViewController(withIdentifier: "ArtistsListVC") as? ArtistsListVC
        objArtistsVC!.strSelectedCategory = self.arrCategoriesData[indexPath.row].id
        self.navigationController?.pushViewController(objArtistsVC!, animated: true)
    }
}
