//
//  BookingHistoryVC.swift
//  Appointments
//
//  Created by Yazeed Alshunify on 05/04/20.
//  Copyright © 2020 Yazeed Alshunify. All rights reserved.
//

import UIKit

class BookingHistoryVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    //MARK : Client Events...
    @IBAction func tapToBack(_ sender: UIControl) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func tapToAppointmentsRequests(_ sender: UIControl) {
        let objAppointmentsRequestsVC = self.storyboard!.instantiateViewController(withIdentifier: "AppointmentsRequestsVC") as? AppointmentsRequestsVC
        self.navigationController?.pushViewController(objAppointmentsRequestsVC!, animated: true)
    }
    
    @IBAction func tapToBookedAppointments(_ sender: UIControl) {
        let objBookedappointmentsVC = self.storyboard!.instantiateViewController(withIdentifier: "BookedAppointmentsVC") as? BookedAppointmentsVC
        self.navigationController?.pushViewController(objBookedappointmentsVC!, animated: true)
    }
}
