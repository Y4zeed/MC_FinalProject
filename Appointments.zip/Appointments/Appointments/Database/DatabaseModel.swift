//
//  DatabaseModel.swift

import Foundation
import UIKit
import FMDB

class DatabaseModel: NSObject
{
    var db = FMDatabase()
    var databasePath = String()
    
    override init()
    {
        super.init()
        
        let success:Bool
        let fileManager = FileManager.default
        success = fileManager.fileExists(atPath: dbPath().0)
        
        if !success {
            let databasePathFromApp = Bundle.main.path(forResource: "UsersData", ofType: "db")
            do {
                try fileManager.copyItem(atPath: databasePathFromApp!, toPath: dbPath().0)
            } catch let error as NSError
            {
                //                if isPrintValue
                //                {
                //                    //print("Error: \(error.localizedDescription)")
                //                }
            }
        }
        db = FMDatabase.init(path: dbPath().0)
        db.open()
        
        if db.open(){
            //print("DB Open")
        }else{
            // print("DB Close")
        }
    }
    
    func dbPath() -> (String, URL)
    {
        let documentURl = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let url = NSURL.fileURL(withPath: documentURl)
        let fileurl = url.appendingPathComponent("UsersData.db")
        let filePath = fileurl.path as String
        return (filePath, url)
    }
    
    func closeDB() -> Void
    {
        db.close()
    }
    
    deinit {
    }
    
}
//
//
//MARK: -
extension DatabaseModel
{
    
    //MARK: - Insert data in Bookings table as per user booked.
    func insertBookingData(bookTime:String, bookMessage:String, bookingDate:String, userId: String,userName: String,userImage: String,userCategoryType : String) -> Bool{
        
        var isSuccess = false
        
        let strIns = "INSERT INTO Bookings (bookTime,bookMessage,bookingDate,userId,userName,userImage,userCategoryType) VALUES (?,?,?,?,?,?,?)"
        if db.executeUpdate(strIns, withArgumentsIn: [bookTime,bookMessage,bookingDate,userId,userName,userImage,userCategoryType])
        {
            print("Inserted at Path_\(dbPath().0)")
            isSuccess = true
            return isSuccess
        }
        
        return isSuccess
    }
    
    //MARK: - Fetch Function for get Artist Categories From Table "ArtistCategory"
    func getCategoriesData() -> [CategoriesModel]
    {
        var userData = [CategoriesModel]()
        //        let strIns = "SELECT * FROM locations WHERE id=\(aLocationId)"
        let strIns = "SELECT * FROM ArtistCategory"
        
        let result: FMResultSet? = db.executeQuery(strIns, withArgumentsIn: ["test"])
        if result != nil
        {
            while (result?.next())!
            {
                let resultData = CategoriesModel.init(dict: result?.resultDictionary! as! NSDictionary)
                userData.append(resultData)
            }
        }
        print("Inserted at Path_\(dbPath().0)")
        return userData
    }
    
    //MARK: - Fetch Function for get Artist Users From Table "User"
    func getUserDataAsPerCategories(aCatId:String) -> [UserModel]
    {
        var userData = [UserModel]()
        let strIns = "SELECT * FROM User WHERE ArtistCategoryid=\(aCatId)"
        
        let result: FMResultSet? = db.executeQuery(strIns, withArgumentsIn: ["ArtistCategoryid"])
        if result != nil
        {
            while (result?.next())!
            {
                let resultData = UserModel.init(dict: result?.resultDictionary! as! NSDictionary)
                userData.append(resultData)
            }
        }
        print("Inserted at Path_\(dbPath().0)")
        return userData
    }
    
    //MARK: - Fetch Function for all bookings From Table "Bookings"
    func getAllBookingsData() -> [BookingsModel]
    {
        var bookingsData = [BookingsModel]()
        let strIns = "SELECT * FROM Bookings ORDER BY Bookingsid DESC"
        
        let result: FMResultSet? = db.executeQuery(strIns, withArgumentsIn: ["test"])
        if result != nil
        {
            while (result?.next())!
            {
                let resultData = BookingsModel.init(dict: result?.resultDictionary! as! NSDictionary)
                bookingsData.append(resultData)
            }
        }
        print("Inserted at Path_\(dbPath().0)")
        return bookingsData
    }
    
    //MARK: - Get bookings data as per date From Table "Bookings"
    func getBookingDataAsPerDate(aDate:String) -> [BookingsModel]
    {
        var bookingsData = [BookingsModel]()
        let strIns = "SELECT * FROM Bookings WHERE bookingDate=\"\(aDate)\""
        
        let result: FMResultSet? = db.executeQuery(strIns, withArgumentsIn: ["bookingDate"])
        if result != nil
        {
            while (result?.next())!
            {
                let resultData = BookingsModel.init(dict: result?.resultDictionary! as! NSDictionary)
                bookingsData.append(resultData)
            }
        }
        print("Inserted at Path_\(dbPath().0)")
        return bookingsData
    }
}
