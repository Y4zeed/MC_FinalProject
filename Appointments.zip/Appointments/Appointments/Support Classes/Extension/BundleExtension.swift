//
//  BundleExtension.swift
//  HomeEscape
//
//  Created by   on 8/17/17.
//  Copyright © 2017  . All rights reserved.
//

import UIKit

//MARK: - Bundle Information
extension Bundle {
    
    //Get Release Version Number
    var releaseVersionNumber: String? {
        
        return infoDictionary?["CFBundleShortVersionString"] as? String
    }
    //Get Build Version Number
    var buildVersionNumber: String? {
        
        return infoDictionary?["CFBundleVersion"] as? String
    }
}
