//
//  UIColorExtension.swift
//  HomeEscape
//
//  Created by   on 8/17/17.
//  Copyright © 2017  . All rights reserved.
//

import UIKit

//MARK: - UIColor Extension
extension UIColor {
    
    //Keyboard header color
    static var keyboardColor:UIColor {
        return UIColor.init(red: 12.0/255.0, green: 108.0/255.0, blue: 182.0/255.0, alpha: 1.0)
    }
    class func appThemeRed() -> UIColor{
        return UIColor(red: 234.0 / 255.0, green: 78.0 / 255.0, blue: 64.0 / 255.0, alpha: 1.0)
    }
    class func appLightRed() -> UIColor{
        return UIColor(red: 253.0 / 255.0, green: 128.0 / 255.0, blue: 128.0 / 255.0, alpha: 1.0)
    }
    class func appLightBlue() -> UIColor{
        return UIColor(red: 0.0 / 255.0, green: 173.0 / 255.0, blue: 236.0 / 255.0, alpha: 1.0)
    }
    class func appLightBlueTransparent() -> UIColor{
        return UIColor(red: 0.0 / 255.0, green: 173.0 / 255.0, blue: 236.0 / 255.0, alpha: 0.6)
    }
    class func appLightGreenTransparent() -> UIColor{
        return UIColor(red: 10.0 / 255.0, green: 205.0 / 255.0, blue: 156.0 / 255.0, alpha: 0.6)
    }
    class func appPurpleLensePin() -> UIColor{
        return UIColor(red: 107.0 / 255.0, green: 52.0 / 255.0, blue: 205.0 / 255.0, alpha: 1)
    }
    class func appPurpleLensePinTransparent() -> UIColor{
        return UIColor(red: 107.0 / 255.0, green: 52.0 / 255.0, blue: 205.0 / 255.0, alpha: 0.7)
    }
}

// MARK: - Hex to UIcolor
func hexStringToUIColor (hex:String) -> UIColor {
    
    var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    
    if (cString.hasPrefix("#")) {
        cString.remove(at: cString.startIndex)
    }
    
    if ((cString.count) != 6) {
        return UIColor.gray
    }
    
    var rgbValue:UInt32 = 0
    Scanner(string: cString).scanHexInt32(&rgbValue)
    
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}
