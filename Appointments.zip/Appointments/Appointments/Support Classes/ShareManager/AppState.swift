//
//  AppState.swift
//  Clubify
//
//  Created by Dude on 2017-01-31.
//  Copyright © 2017 Jason Lumsden. All rights reserved.
//

import UIKit

class AppState: NSObject {
    //Updated if user settings suscesfully updated
    
//    private var _user:UserModel?
//    var user: UserModel? {
//        set { _user = newValue! }
//        get { return (_user) }
//    }
//
//    private var _placeData:PlacesData?
//    var placeData: PlacesData? {
//        set { _placeData = newValue! }
//        get { return (_placeData) }
    //    }
    
    override init() {
        super.init()
    }
    
    class var sharedInstance: AppState {
        struct Singleton {
            static let instance = AppState()
        }
        return Singleton.instance
    }
    
    //
}

    
