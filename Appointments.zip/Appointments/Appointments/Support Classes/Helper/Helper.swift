//
//  Helper.swift
//  CommonClass
//

import Foundation
import UIKit
import AVFoundation
import SystemConfiguration



//MARK: - Device Type
enum UIUserInterfaceIdiom : Int {
    case Unspecified
    case Phone
    case Pad
}

//MARK: - Current Open Screen For Push Notification
enum MediaType : String {
    case Image = "IMG"
    case Video  = "VID"
}
struct DeviceType {
    static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
    static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
    static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
    static let IS_IPHONE_6PLUS      = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
    static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
    static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    static let IS_IPHONE_X          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 812.0
    static let IS_IPHONE_XSMax_XR   = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 896.0
}

//MARK: - Screen Size
struct ScreenSize {
    
    static let width         = UIScreen.main.bounds.size.width
    static let height        = UIScreen.main.bounds.size.height
    static let SCREEN_MAX_LENGTH    = max(ScreenSize.width, ScreenSize.height)
    static let SCREEN_MIN_LENGTH    = min(ScreenSize.width, ScreenSize.height)
}

//MARK: - Font Layout
struct FontName {
    //Font Name List
    static let CoconNextArabicLight = "CoconNextArabic-Light"
    static let Helvetica = "Helvetica"
    static let HelveticaNeue = "HelveticaNeue"
    static let PlayfairDisplaySCRegular = "PlayfairDisplaySC-Regular"
    static let PlayfairDisplayRegular = "PlayfairDisplay-Regular"
    static let PlayfairDisplayBold = "PlayfairDisplay-Bold"

}
let calnderFont = UIFont(name: FontName.PlayfairDisplayRegular, size: 14)
let searchBarFont = UIFont(name: FontName.PlayfairDisplayRegular, size: 14)

//MARK: - StoryBoards Constant
struct storyBoards {
    static let Main = UIStoryboard(name: "Main", bundle: Bundle.main)
}
func setFontLayout(strFontName:String,fontSize:CGFloat) -> UIFont {
    
    //Set auto font size in different devices.
    return UIFont(name: strFontName, size: (ScreenSize.width / 375) * fontSize)!
}
func showAlert(title: NSString, message: String) {
    
    let obj = UIAlertView(title: title as String, message: message, delegate: nil, cancelButtonTitle:"OK")
    obj.show()
}
//MARK: - Set Color Method
func getColor(r: Float, g: Float, b: Float, aplha: Float)-> UIColor {
    
  return UIColor(red: CGFloat(Float(r / 255.0)), green: CGFloat(Float(g / 255.0)) , blue: CGFloat(Float(b / 255.0)), alpha: CGFloat(aplha))
}

//MARK: - Scaling
struct DeviceScale {
    
    static let x = ScreenSize.width / 375.0
    static let y = ScreenSize.height / 667.0
    static let xy = (DeviceScale.x + DeviceScale.y) / 2.0
    static let x_iPhone:Float = (DeviceType.IS_IPAD || DeviceType.IS_IPAD_PRO ? Float(1.0) : Float(ScreenSize.width / 375.0))
    static let y_iPhone:Float = (DeviceType.IS_IPAD || DeviceType.IS_IPAD_PRO ? Float(1.0) : Float(ScreenSize.height / 667.0))
}

//MARK: - Helper Class
class Helper {
//MARK: - Shared Instance
    static let sharedInstance : Helper = {
        let instance = Helper()
        return instance
    }()

    static let isDevelopmentBuild:Bool = true
 
}

//MARK: - Set Globally Alert View..
extension UIViewController {
    func popupAlert(title: String?, message: String?, actionTitles:[String?], actions:[((UIAlertAction) -> Void)?]) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for (index, title) in actionTitles.enumerated() {
            let action = UIAlertAction(title: title, style: .default, handler: actions[index])
            alert.addAction(action)
        }
        self.present(alert, animated: true, completion: nil)
    }
    
    func popupAlertActionSheet(title: String?, message: String?, actionTitles:[String?], actions:[((UIAlertAction) -> Void)?]) {
        
        let attributedString = NSAttributedString(string: title!, attributes: [
            NSAttributedString.Key.font : UIFont.init(name: FontName.CoconNextArabicLight, size: 18)!
            ])
        
        let alert = UIAlertController(title: "", message: message, preferredStyle: .actionSheet)
        alert.setValue(attributedString, forKey: "attributedTitle")

        for (index, title) in actionTitles.enumerated() {
            let action = UIAlertAction(title: title, style:(title == "Cancel") ? .cancel : .default, handler: actions[index])
            alert.addAction(action)
        }
        self.present(alert, animated: true, completion: nil)
    }
}

//Radians To Degrees
func radiansToDegrees(radians: Double) -> Double {
    return radians * 180.0 / .pi
}

//Degrees To Radians
func degreesToRadians(degrees: Double) -> Double {
    return degrees * .pi / 180.0
}


//MARK: -Theme all methods
//MARK: -
enum AppThemeType : String {
    case dark = "1"
    case light = "2"
}
let goldThemeColor: UIColor  = UIColor(red: 189.0/255.0, green: 167.0/255.0, blue: 99.0/255.0, alpha: 1.0)
let pinkThemeColor: UIColor  = UIColor(red: 231.0/255.0, green: 174.0/255.0, blue: 184.0/255.0, alpha: 1.0)

//MARK: - Show/hide view method
func setView(view: UIView, hidden: Bool) {
    UIView.transition(with: view, duration: 0.5, options: .transitionCrossDissolve, animations: {
        view.isHidden = hidden
    })
}
